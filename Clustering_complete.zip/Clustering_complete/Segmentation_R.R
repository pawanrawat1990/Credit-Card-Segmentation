
mydata <- read.csv( "D:/R Analytics/Analytixlabs/Clustering/CC GENERAL.csv",header = T)
View(mydata)
str(mydata)
colnames(mydata)

mystats <- function(x){
  n <- length(x)
  nmiss <-  sum(is.na(x))
  a <- x[!is.na(x)]
  m <- mean(a)
  s <- sd(a)
  min <- min(a)
  max <- max(a)
  p90 <- quantile(a,0.90)
  p95 <- quantile(a,0.95)
  p99 <- quantile(a,0.99)
  UC <- m+3*s
  LC <- m-3*s
  return(c(n=n,nmiss=nmiss,mean=m,stdev=s,p90= p90,p95=p95,p99=p99,
           min=min,max=max,UC=UC,LC=LC))
}

vars <- c("BALANCE",	"BALANCE_FREQUENCY",	"PURCHASES",	"ONEOFF_PURCHASES",	"INSTALLMENTS_PURCHASES",	"CASH_ADVANCE",	"PURCHASES_FREQUENCY",	"ONEOFF_PURCHASES_FREQUENCY",	"PURCHASES_INSTALLMENTS_FREQUENCY",	"CASH_ADVANCE_FREQUENCY",	"CASH_ADVANCE_TRX",	"PURCHASES_TRX",	"CREDIT_LIMIT",
      "PAYMENTS",	"MINIMUM_PAYMENTS",	"PRC_FULL_PAYMENT",	"TENURE")

diag_stats <- t(data.frame(apply(mydata[vars],2,mystats)))
View(diag_stats)   

write.csv(diag_stats, file = "D:/R Analytics/Analytixlabs/Clustering/diag_stats_cluster.csv")

#####Oultliers Capping manual - mean + 3*Standard deviation ####

mydata$BALANCE[mydata$BALANCE>7809.07046604776] <-7809.07046604776
mydata$PURCHASES[mydata$PURCHASES>7413.10917913822] <-7413.10917913822
mydata$ONEOFF_PURCHASES[mydata$ONEOFF_PURCHASES>5572.10112326315] <-5572.10112326315
mydata$INSTALLMENTS_PURCHASES[mydata$INSTALLMENTS_PURCHASES>3124.08199021888] <-3124.08199021888
mydata$CASH_ADVANCE[mydata$CASH_ADVANCE>7270.36274239518] <-7270.36274239518
mydata$CASH_ADVANCE_FREQUENCY[mydata$CASH_ADVANCE_FREQUENCY>0.735508364777686] <-0.735508364777686
mydata$CASH_ADVANCE_TRX[mydata$CASH_ADVANCE_TRX>23.72276704814] <-23.72276704814
mydata$PURCHASES_TRX[mydata$PURCHASES_TRX>89.2827797318889] <-89.2827797318889
mydata$CREDIT_LIMIT[mydata$CREDIT_LIMIT>15410.8966268601] <-15410.8966268601
mydata$PAYMENTS[mydata$PAYMENTS>10418.3351227384] <-10418.3351227384
mydata$MINIMUM_PAYMENTS[mydata$MINIMUM_PAYMENTS>7981.08894579092] <-7981.08894579092

#####Missing Value imputation#######

mydata$CREDIT_LIMIT[is.na(mydata$CREDIT_LIMIT)] <- median(mydata$CREDIT_LIMIT,na.rm = T)
mydata$MINIMUM_PAYMENTS[is.na(mydata$MINIMUM_PAYMENTS)] <- median(mydata$MINIMUM_PAYMENTS,na.rm = T)


######## New Features ################################################

mydata$PURCHASES_PER_TRANSAC <- ifelse(mydata$PURCHASES==0,0,
                                       ifelse(mydata$PURCHASES_TRX==0,0,mydata$PURCHASES/mydata$PURCHASES_TRX))
mydata$INSTALL_PURCHASE_PERCENT <- ifelse(mydata$PURCHASES==0,0,
                                        ifelse(mydata$INSTALLMENTS_PURCHASES==0,0,mydata$INSTALLMENTS_PURCHASES/mydata$PURCHASES))
mydata$ONEOFF_PURCHASES_PERCENT <- ifelse(mydata$PURCHASES==0,0,
                                          ifelse(mydata$ONEOFF_PURCHASES==0,0,mydata$ONEOFF_PURCHASES/mydata$PURCHASES))

mydata$MONTHLY_AVG_PURCHASE <- mydata$PURCHASES/mydata$TENURE

mydata$BALANCE_TO_CREDITLIMIT <- ifelse(mydata$BALANCE==0,0,
                                        ifelse(mydata$CREDIT_LIMIT==0,0,mydata$BALANCE/mydata$CREDIT_LIMIT))

mydata$PAYMENT_TO_MIN_RATIO <- ifelse(mydata$PAYMENTS==0,0,
                                      ifelse(mydata$MINIMUM_PAYMENTS==0,0,mydata$MINIMUM_PAYMENTS/mydata$PAYMENTS))

####Factor Analysis#########################

names(mydata)

vars_1 <- c("BALANCE",	"BALANCE_FREQUENCY",	"PURCHASES",	"ONEOFF_PURCHASES",	"INSTALLMENTS_PURCHASES",	
            "CASH_ADVANCE",	"PURCHASES_FREQUENCY",	"ONEOFF_PURCHASES_FREQUENCY",	"PURCHASES_INSTALLMENTS_FREQUENCY",	"CASH_ADVANCE_FREQUENCY",	"CASH_ADVANCE_TRX",	"PURCHASES_TRX",	"CREDIT_LIMIT",
            "PAYMENTS",	"MINIMUM_PAYMENTS",	"TENURE","PURCHASES_PER_TRANSAC","PRC_FULL_PAYMENT",
            "INSTALL_PURCHASE_PERCENT","ONEOFF_PURCHASES_PERCENT ","MONTHLY_AVG_PURCHASE","BALANCE_TO_CREDITLIMIT","PAYMENT_TO_MIN_RATIO")

numeric_var <- sapply(mydata, is.numeric)

corrm <- cor(mydata[numeric_var])   ### Correlation Metrix######

require(psych)
require(GPArotation)



### Deciding number of factors using scree plot & kaiser test (Number of eigen value over 1)

scree(corrm, factors=T,pc=T,main="scree plot",hline=NULL,add=FALSE)

eigen(corrm)$values

require(dplyr)

eigen_values <- mutate(data.frame(eigen(corrm)$values),
                    cum_sum_eigen=cumsum(eigen.corrm..values),
                    pct_var=eigen.corrm..values/sum(eigen.corrm..values),
                    pct_cumsum_var= cum_sum_eigen/sum(eigen.corrm..values))

write.csv(eigen_values,file = "D:/R Analytics/Analytixlabs/Clustering/eigen_values.csv")

FA <- fa(r=corrm,7,rotate="varimax",fm="ml")
print(FA)
FA_Sort <- fa.sort(FA)
ls(FA_Sort)
FA_Sort$loadings
FA_Sort$e.values

Loadings <- data.frame(FA_Sort$loadings[1:ncol(mydata[numeric_var]),])

# write.csv(Loadings, file= "D:/R Analytics/Analytixlabs/Clustering/Factor_loadings.csv")

factors_vars <- c("MONTHLY_AVG_PURCHASE",	"ONEOFF_PURCHASES",	"PURCHASES_INSTALLMENTS_FREQUENCY",	"PURCHASES_FREQUENCY",	"CASH_ADVANCE_FREQUENCY",	"CASH_ADVANCE",	"ONEOFF_PURCHASES_FREQUENCY",	"BALANCE_TO_CREDITLIMIT",	"PAYMENT_TO_MIN_RATIO",	"MINIMUM_PAYMENTS","CREDIT_LIMIT",	"INSTALLMENTS_PURCHASES")

input <- mydata[,factors_vars]

input_datafinal <- scale(input)

###Building Clusters###########

cluster_three <- kmeans(input_datafinal,3)
cluster_four <- kmeans(input_datafinal,4)
cluster_five <- kmeans(input_datafinal,5)
cluster_six <- kmeans(input_datafinal,6)

cluster_three$cluster

mydata_new <- cbind(mydata,km_clust_3=cluster_three$cluster,km_clust_4=cluster_four$cluster,km_clust_5=cluster_five$cluster ,km_clust_6=cluster_six$cluster)
View(mydata_new)

###Profiling

#Converting into factors
mydata_new$km_clust_3=factor(mydata_new$km_clust_3)
mydata_new$km_clust_4=factor(mydata_new$km_clust_4)
mydata_new$km_clust_5=factor(mydata_new$km_clust_5)
mydata_new$km_clust_6=factor(mydata_new$km_clust_6)

require(tables)
profile<-tabular(1+MONTHLY_AVG_PURCHASE+	ONEOFF_PURCHASES+	PURCHASES_INSTALLMENTS_FREQUENCY+	PURCHASES_FREQUENCY+	CASH_ADVANCE_FREQUENCY+	CASH_ADVANCE+	
                   ONEOFF_PURCHASES_FREQUENCY+	BALANCE_TO_CREDITLIMIT+	PAYMENT_TO_MIN_RATIO+	CREDIT_LIMIT+	INSTALLMENTS_PURCHASES+MINIMUM_PAYMENTS~mean+(mean*km_clust_3)+(mean*km_clust_4)+(mean*km_clust_5)+(mean*km_clust_6),
                 data=mydata_new)
profile1<-as.matrix(profile)
profile1<-data.frame(profile1)
View(profile1)


profile<-tabular(1~length+(length*km_clust_3)+(length*km_clust_4)+(length*km_clust_5)+(length*km_clust_6),
                 data=mydata_new)
profile2<-as.matrix(profile)
profile2<-data.frame(profile2)
View(profile2)

write.csv(profile1,"D:/R Analytics/Analytixlabs/Clustering/Profile_1.csv",row.names = F)
write.csv(profile2,"D:/R Analytics/Analytixlabs/Clustering/Profile_2.csv",row.names = F)



###### END ##################################################################################################














                


